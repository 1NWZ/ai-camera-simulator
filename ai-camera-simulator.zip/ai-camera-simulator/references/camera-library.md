# 原始排版参考相机库

理光负片例外：固定使用[本次图1机身](../assets/cameras/ricoh-fixed.png)，见[理光规则](ricoh-current.md)。旧库1–5只供其他三种模板随机调用。

用户已授权使用最初五张排版参考中的真实机身摄影。默认随机从随包库选择一张，替代 AI 生成统一银色机身的流程。库中是原图的上半部裁切，保留原材质、按钮、机身文字、灯光、背景和手持关系；不把它们重绘成同一款机身。

## 选择与合成

```bash
python scripts/pick_camera.py --style olympus
```

输出 `camera` 路径、`id`、`selection_seed` 与 `screen_quad`。每次请求重新随机选择；同一轮修改效果时复用已选机身。知道上一次使用的 id 时可用 `--exclude 3` 避免连续重复。调试可用 `--seed` 重现选择或 `--id 3` 指定机身；相机选择种子与调色颗粒种子分开。

先查看所选底板，再把返回的 `camera` 和 `screen_quad` 传给 `render.py`：

```bash
python scripts/render.py render --source /path/input.jpg --ai /path/ai.png \
  --camera /path/library/camera.png --screen-quad x0 y0 x1 y1 x2 y2 x3 y3 \
  --style olympus --out-dir /path/new-output
```

四点顺序：左上、右上、右下、左下；坐标为裁切后底板的原始像素。脚本透视嵌入输入图，覆盖旧屏幕照片与屏内UI，随后模拟轻显示偏色和纹理。不得把参考里原来的水果、花或人留在屏幕里，不覆盖实体按钮和屏幕框。替换后检查边缘有没有残留旧图；必要时调整四点，而不是重新生成整台相机。

相机库与色彩模板独立：选择富士色彩时可使用库中不同品牌外壳，不宣称外壳品牌决定色彩准确性。用户当前授权包含原始前五台，其中第6台带凸起取景器，是原始参考库的允许例外。若需要新生成机身，仍遵循复古卡片式CCD外形。

|ID|相机底板|特征|
|---|---|---|
|1|[查看](../assets/cameras/camera-01.png)|灰银紧凑机、青灰环境、圆润机背|
|2|[查看](../assets/cameras/camera-02.png)|银色小卡片机、冷灰桌面|
|3|[查看](../assets/cameras/camera-03.png)|香槟银机背、绿色背景|
|4|[查看](../assets/cameras/camera-04.png)|银灰卡片机、白色布面|
|5|[查看](../assets/cameras/camera-05.png)|银色小屏卡片机、圆盘按钮|

机身库完整随 Skill 搬迁，源文件映射与四点坐标见 `assets/cameras/index.json`。外部 Downloads 或 Desktop 路径不作为运行依赖。最终维持1500×2000、上下各1000px；上图缩放到3:2，不拉伸机身。
