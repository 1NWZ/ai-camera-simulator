#!/usr/bin/env python3
"""从随包原始参考相机库随机选一台，输出路径和LCD四点坐标。"""
import argparse,json,random
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--seed',type=int)
p.add_argument('--exclude',type=int,nargs='*',default=[])
p.add_argument('--id',type=int)
p.add_argument('--style',choices=['ricoh','fujifilm','kodak','olympus'],required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]/'assets/cameras'
if a.style == 'ricoh':
 r=json.loads((root/'ricoh-fixed.json').read_text());r['camera']=str(root/r['file']);r['selection']='fixed';print(json.dumps(r,ensure_ascii=False,indent=2));raise SystemExit(0)
rows=json.loads((root/'index.json').read_text())
rows=[r for r in rows if r['id'] not in a.exclude and (a.id is None or r['id']==a.id)]
if not rows:p.error('没有符合条件的相机')
seed=a.seed if a.seed is not None else random.SystemRandom().randrange(2**32)
r=random.Random(seed).choice(rows)
r['camera']=str(root/r['file']);r['selection_seed']=seed
print(json.dumps(r,ensure_ascii=False,indent=2))
