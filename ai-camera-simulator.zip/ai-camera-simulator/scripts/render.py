#!/usr/bin/env python3
"""AI 相机后期与双联图合成；需要 Pillow、NumPy，不调用 AI 服务。"""
import argparse
import json
from pathlib import Path
import random
import numpy as np
from PIL import Image, ImageOps, ImageFilter

STYLES = {
    'ricoh': dict(name='理光负片', saturation=.91, exposure=.035, contrast=.94,
                  lift=.025, shadow=[-.004,.012,-.002], light=[.016,.009,-.010], bloom=.045, noise=.008),
    'fujifilm': dict(name='富士胶片', saturation=.89, exposure=.02, contrast=1.03,
                     lift=.010, shadow=[-.024,.015,.023], light=[.027,.013,.011], bloom=.12, noise=.016),
    'kodak': dict(name='柯达色彩', saturation=.91, exposure=.10, contrast=1.08,
                  lift=.009, shadow=[.007,.010,-.003], light=[.052,.022,-.033], bloom=.19, noise=.021),
    'olympus': dict(name='奥林巴斯CCD', saturation=1.13, exposure=.13, contrast=1.17,
                    lift=0, shadow=[-.009,.002,.010], light=[.014,.009,.001], bloom=.07, noise=.016),
}


def read(path):
    with Image.open(path) as im:
        return ImageOps.exif_transpose(im).convert('RGB')


def bitmap(array):
    return Image.fromarray(np.uint8(np.clip(array, 0, 1) * 255 + .5))


def tone(im, style, strength, seed):
    """对 AI 成片作温和补充，噪声偏向暗部，晕光只来自高光。"""
    p = STYLES[style]
    base = np.asarray(im, dtype=np.float32) / 255
    a = base.copy()
    luma = np.sum(a * np.array([.2126,.7152,.0722], dtype=np.float32), axis=2, keepdims=True)
    a = luma + (a - luma) * p['saturation']
    a = (a - .5) * p['contrast'] + .5
    a *= 2 ** p['exposure']
    shadow = (1-luma)**2
    highlight = luma**2
    a += shadow * np.array(p['shadow']) + highlight * np.array(p['light'])
    a += p['lift'] * (1-luma)
    if style == 'ricoh':
        # 翠绿与橙红只作用于对应原有色块，不对全图染色。
        green = np.clip((base[...,1:2]-np.maximum(base[...,0:1],base[...,2:3]))*4,0,1)
        warm = np.clip((base[...,0:1]-base[...,2:3])*3,0,1)
        a += green*np.array([-.010,.014,.004]) + warm*np.array([.010,.001,-.005])
        a -= .035*np.clip((luma-.65)/.35,0,1)**2
    mask = np.clip((luma - .64) / .36, 0, 1)
    glow = bitmap(np.clip(a,0,1) * mask).filter(ImageFilter.GaussianBlur(max(im.width / 190, 1)))
    a += np.asarray(glow, dtype=np.float32) / 255 * p['bloom']
    # 轻微暗角保留主体，采用位置连续的椭圆衰减。
    yy, xx = np.mgrid[-1:1:complex(im.height), -1:1:complex(im.width)]
    a *= (1 - .055 * np.clip((xx*xx+yy*yy)/2,0,1))[...,None]
    if style == 'olympus':
        small = bitmap(a).resize((max(1,im.width//2), max(1,im.height//2)), Image.Resampling.BILINEAR)
        a = .75*a + .25*np.asarray(small.resize(im.size,Image.Resampling.BILINEAR),dtype=np.float32)/255
    rng = np.random.default_rng(seed)
    mono = rng.normal(0,1,(*a.shape[:2],1))
    chroma = rng.normal(0,1,a.shape)
    grain = .66*mono + (.55 if style == 'olympus' else .16)*chroma
    a += grain * p['noise'] * (.35 + .85*shadow)
    return bitmap(base + strength * (a-base))


def material(im, style, amount, seed, leak='off', protect_boxes=()):
    """对下图补充轻光学软化、相关颗粒与扫描偏色，不添加 LCD 网格。"""
    if amount == 0:
        return im.copy()
    base = np.asarray(im, dtype=np.float32)/255
    h,w = base.shape[:2]
    rng = np.random.default_rng(seed+101)
    radius = dict(ricoh=.6,fujifilm=.9,kodak=.85,olympus=.75)[style]*w/1500
    soft = np.asarray(im.filter(ImageFilter.GaussianBlur(radius)),dtype=np.float32)/255
    a = base*.3 + soft*.7
    luma = np.sum(base*np.array([.2126,.7152,.0722]),axis=2,keepdims=True)
    coarse = rng.normal(128,27,(max(2,h//3),max(2,w//3)))
    coarse_im = Image.fromarray(np.uint8(np.clip(coarse,0,255))).resize((w,h),Image.Resampling.BILINEAR)
    correlated = (np.asarray(coarse_im,dtype=np.float32)-128)/27
    fine = rng.normal(0,1,(h,w))
    sigma = dict(ricoh=.005,fujifilm=.023,kodak=.010,olympus=.009)[style]
    a += (fine*.58 + correlated*.42)[...,None]*sigma*(.65+.65*(1-luma))
    yy,xx = np.mgrid[0:1:complex(h),0:1:complex(w)]
    if style == 'fujifilm':
        phase = rng.uniform(0,6.28)
        field = np.sin(xx*3.1+phase)*np.cos(yy*2.7-phase)
        a += field[...,None]*np.array([.007,-.003,.004])
        if leak != 'off':
            edge = xx if leak == 'left' else 1-xx
            # 窄边、不对称、无硬边；主体区域可用 protect_boxes 衰减。
            field = np.exp(-edge/.055)*(.25+.75*np.exp(-((yy-.3)/.36)**2))
            a += field[...,None]*np.array([.19,.065,.012])
    weight = np.ones((h,w),dtype=np.float32)
    for x0,y0,x1,y1 in protect_boxes:
        mask = Image.new('L',(w,h),0)
        from PIL import ImageDraw
        ImageDraw.Draw(mask).rectangle((round(x0*w),round(y0*h),round(x1*w),round(y1*h)),fill=255)
        smooth=np.asarray(mask.filter(ImageFilter.GaussianBlur(max(1,w*.012))),dtype=np.float32)/255
        weight *= 1-.8*smooth
    return bitmap(base+amount*weight[...,None]*(a-base))


def lcd(im, amount, seed):
    """只对 LCD 内部施加显示介质效果，不对机身与下图施加行纹。"""
    if amount == 0:
        return im.copy()
    w,h=im.size
    base=np.asarray(im,dtype=np.float32)/255
    logical_w=max(1,min(w,420)); logical_h=max(1,round(h*logical_w/w))
    small=im.resize((logical_w,logical_h),Image.Resampling.BILINEAR)
    screen=small.resize((w,h),Image.Resampling.BILINEAR).filter(ImageFilter.GaussianBlur(max(.15,w/1500)))
    a=np.asarray(screen,dtype=np.float32)/255
    a=a*np.array([.965,1.014,1.025])+.012
    yy,xx=np.mgrid[0:1:complex(h),0:1:complex(w)]
    a *= (1-.032*(xx-.35)**2-.028*(yy-.4)**2)[...,None]
    rows=np.cos(np.arange(h)*np.pi)*.006
    columns=np.cos(np.arange(w)*2*np.pi/3)*.003
    a += rows[:,None,None]+columns[None,:,None]
    a += np.random.default_rng(seed+211).normal(0,.0035,(h,w,1))
    return bitmap(base+amount*(a-base))


def ccd_finish(im, amount=1.0, highlight_boxes=()):
    """已确认的 CCD 收尾：低对比度、轻过曝、仅高光柔晕。"""
    if amount == 0:
        return im.copy()
    original = np.asarray(im,dtype=np.float32)/255
    a = original.copy()
    y = (a*np.array([.2126,.7152,.0722])).sum(axis=2,keepdims=True)
    # 保留已认可的蓝绿关系，只用亮度相关偏移收柔两端。
    a = np.asarray(bitmap(a+.042*(1-y)**2-.052*y**2),dtype=np.float32)/255
    y = (a*np.array([.2126,.7152,.0722])).sum(axis=2,keepdims=True)
    mask = np.clip((y-.58)/.42,0,1)
    high = Image.fromarray(np.uint8(np.clip(a*mask,0,1)*255))
    glow = np.asarray(high.filter(ImageFilter.GaussianBlur(10*im.width/1500)),dtype=np.float32)/255
    b = a*1.055+glow*.14
    protection = np.zeros((*a.shape[:2],1),dtype=np.float32)
    from PIL import ImageDraw
    for x0,y0,x1,y1 in highlight_boxes:
        m = Image.new('L',im.size,0)
        ImageDraw.Draw(m).ellipse(tuple(round(v*d) for v,d in zip((x0,y0,x1,y1),(im.width,im.height,im.width,im.height))),fill=255)
        field = np.asarray(m.filter(ImageFilter.GaussianBlur(35*im.width/1500)),dtype=np.float32)[...,None]/255
        protection = np.maximum(protection,field)
    b = a+(b-a)*(1-.4*protection)
    return bitmap(b) if amount == 1 else bitmap(original+amount*(b-original))


def fit(im, size, focus=(.5,.5)):
    return ImageOps.fit(im, size, method=Image.Resampling.LANCZOS, centering=tuple(focus))


def render(args):
    if args.style == 'ricoh':
        library=Path(__file__).resolve().parents[1]/'assets/cameras'
        fixed=json.loads((library/'ricoh-fixed.json').read_text())
        args.camera=str(library/fixed['file'])
        args.screen_quad=fixed['screen_quad']
        args.screen_box=None
    elif not args.camera or not (args.screen_quad or args.screen_box):
        raise ValueError('其他模板需提供 camera 与屏幕坐标')
    # CCD 使用用户认可的基础配方，其余模板保留原默认值。
    if args.strength is None: args.strength = .45 if args.style == 'olympus' else .55
    if args.texture is None: args.texture = .7 if args.style == 'olympus' else .55
    if args.screen_strength is None: args.screen_strength = .75 if args.style == 'olympus' else .55
    if args.ccd_finish is None: args.ccd_finish = 1.0 if args.style == 'olympus' else 0.0
    if args.style != 'olympus' and args.ccd_finish != 0:
        raise ValueError('ccd-finish 仅适用于 CCD 模板')
    for value in (args.texture,args.screen_strength,args.ccd_finish):
        if not 0 <= value <= 1:
            raise ValueError('texture、screen-strength 和 ccd-finish 应在 0–1 之间')
    if args.leak != 'off' and args.style != 'fujifilm':
        raise ValueError('边缘漏光仅适用于富士模板')
    for x0,y0,x1,y1 in args.protect_box + args.highlight_protect_box:
        if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
            raise ValueError('protect-box 应为有效的归一化矩形')
    if not 0 <= args.strength <= 1:
        raise ValueError('strength 应在 0–1 之间')
    if not 256 <= args.width <= 6000 or args.width % 3:
        raise ValueError('width 应在 256–6000 之间且为 3 的倍数，以保证严格 3:4')
    if any(not 0 <= f <= 1 for f in args.focus):
        raise ValueError('focus 应在 0–1 之间')
    source, ai, camera = read(args.source), read(args.ai), read(args.camera)
    if args.crop:
        x0,y0,x1,y1 = args.crop
        if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
            raise ValueError('crop 必须是有效的归一化矩形')
        box = tuple(round(v*s) for v,s in zip(args.crop,[ai.width,ai.height,ai.width,ai.height]))
        if box[2] <= box[0] or box[3] <= box[1]:
            raise ValueError('crop 太小，像素区域为空')
        ai = ai.crop(box)
    if args.screen_quad:
        quad = np.asarray(args.screen_quad,dtype=float).reshape(4,2)
        if not np.isfinite(quad).all() or np.any(quad<0) or np.any(quad[:,0]>camera.width) or np.any(quad[:,1]>camera.height):
            raise ValueError('screen-quad 超出底板')
        # 顺序为左上、右上、右下、左下；将显示矩形投影到原照片屏幕。
        w = max(2,round(max(np.linalg.norm(quad[1]-quad[0]),np.linalg.norm(quad[2]-quad[3]))))
        h = max(2,round(max(np.linalg.norm(quad[3]-quad[0]),np.linalg.norm(quad[2]-quad[1]))))
        screen = lcd(fit(source,(w,h),args.focus),args.screen_strength,args.seed)
        uv = [(0,0),(w,0),(w,h),(0,h)]
        matrix=[]; vector=[]
        for (x,y),(u,v) in zip(quad,uv):
            matrix += [[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]
            vector += [u,v]
        try: coeff=np.linalg.solve(matrix,vector)
        except np.linalg.LinAlgError: raise ValueError('screen-quad 四点无效')
        layer=screen.transform(camera.size,Image.Transform.PERSPECTIVE,coeff,Image.Resampling.BICUBIC)
        from PIL import ImageDraw
        mask=Image.new('L',camera.size,0)
        ImageDraw.Draw(mask).polygon([tuple(p) for p in quad],fill=255)
        camera.paste(layer,(0,0),mask)
    else:
        left,top,right,bottom = args.screen_box
        if not (0 <= left < right <= camera.width and 0 <= top < bottom <= camera.height):
            raise ValueError('screen-box 超出相机底板')
        screen=lcd(fit(source,(right-left,bottom-top),args.focus),args.screen_strength,args.seed)
        camera.paste(screen,(left,top))
    # 总图严格 3:4；上下 5:5，每块严格 3:2。
    top_height = bottom_height = args.width * 2 // 3
    upper = fit(camera,(args.width,top_height))
    lower = tone(fit(ai,(args.width,bottom_height),args.focus),args.style,args.strength,args.seed)
    lower = material(lower,args.style,args.texture,args.seed,args.leak,args.protect_box)
    lower = ccd_finish(lower,args.ccd_finish,args.highlight_protect_box)
    poster = Image.new('RGB',(args.width,top_height+bottom_height))
    poster.paste(upper,(0,0))
    poster.paste(lower,(0,top_height))
    out = Path(args.out_dir)
    names = ['camera-effect.png','effect-only.png','recipe.json']
    if any((out/n).exists() for n in names):
        raise ValueError('目标已有同名文件，请换一个输出目录以保留旧版本')
    out.mkdir(parents=True,exist_ok=True)
    lower.save(out/names[1])
    poster.save(out/names[0])
    recipe = dict(style=args.style, label=STYLES[args.style]['name'], strength=args.strength,
                  texture=args.texture, screen_strength=args.screen_strength, leak=args.leak,
                  protect_boxes=args.protect_box, ccd_finish=args.ccd_finish, highlight_protect_boxes=args.highlight_protect_box, pipeline_version=4, seed=args.seed, crop=args.crop, focus=args.focus, screen_box=args.screen_box, screen_quad=args.screen_quad,
                  source=str(Path(args.source).resolve()), ai_input=str(Path(args.ai).resolve()),
                  camera_input=str(Path(args.camera).resolve()), width=args.width,
                  top_height=top_height, bottom_height=bottom_height,
                  parameters=STYLES[args.style], note='仅记录代码后期；AI 来源由执行者核实。品牌名为审美方向。')
    (out/names[2]).write_text(json.dumps(recipe,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'outputs':[str((out/n).resolve()) for n in names]},ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command',required=True)
    choose = sub.add_parser('choose',help='随机选择一次，将同一结果用于 AI 和代码阶段')
    choose.add_argument('--seed',type=int,default=None)
    run = sub.add_parser('render',help='为真正的 AI 输出添加质感，并把原图嵌入相机屏幕')
    for key in ['source','ai','out-dir']:
        run.add_argument('--'+key,required=True)
    run.add_argument('--camera')
    run.add_argument('--style',choices=list(STYLES),required=True)
    screen_group = run.add_mutually_exclusive_group(required=False)
    screen_group.add_argument('--screen-box',type=int,nargs=4)
    screen_group.add_argument('--screen-quad',type=float,nargs=8)
    run.add_argument('--strength',type=float,default=None)
    run.add_argument('--texture',type=float,default=None)
    run.add_argument('--screen-strength',type=float,default=None)
    run.add_argument('--ccd-finish',type=float,default=None)
    run.add_argument('--highlight-protect-box',type=float,nargs=4,action='append',default=[])
    run.add_argument('--leak',choices=['off','left','right'],default='off')
    run.add_argument('--protect-box',type=float,nargs=4,action='append',default=[])
    run.add_argument('--seed',type=int,default=27)
    run.add_argument('--width',type=int,default=1500)
    run.add_argument('--crop',type=float,nargs=4)
    run.add_argument('--focus',type=float,nargs=2,default=[.5,.5])
    args = parser.parse_args()
    if args.command == 'choose':
        seed = args.seed if args.seed is not None else random.SystemRandom().randrange(2**32)
        style = random.Random(seed).choice(list(STYLES))
        print(json.dumps(dict(style=style,label=STYLES[style]['name'],seed=seed),ensure_ascii=False))
    else:
        try:
            render(args)
        except (ValueError,OSError) as exc:
            parser.error(str(exc))


if __name__ == '__main__':
    main()
